﻿using WebApplication1.Models.Cancellation_Model_;
using WebApplication1.Models.Flight_Model_;
using WebApplication1.Models.Payment_Model_;
using WebApplication1.Models.SeatBooking_Model_;
using WebApplication1.Models.User_Model_;

namespace WebApplication1.Models.Reservation_Model_
{
    public enum ReservationStatus
    {
        Pending,
        Confirmed,
        Cancelled,
        Completed
    }

    public class Reservation
    {
        public int Id { get; set; }
        public int FlightId { get; set; }
        public int UserId { get; set; }
        public DateTime ReservationDate { get; set; }
        public ReservationStatus Status { get; set; }
        public decimal TotalAmount { get; set; }

        public virtual Flight? Flight { get; set; }
        public virtual User? User { get; set; }
        public virtual ICollection<SeatBooking>? SeatBookings { get; set; }
        public virtual Payment? Payment { get; set; }
        public virtual Cancellation? Cancellation { get; set; }

    }
}
