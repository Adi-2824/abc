﻿using WebApplication1.Models.Flight_Model_;

namespace WebApplication1.Models.Reservation_Model_
{
    public class ReservationDto
    {
        public int Id { get; set; }
        public int FlightId { get; set; }
        public DateTime ReservationDate { get; set; }
        public string? Status { get; set; }
        public decimal TotalAmount { get; set; }
        public List<SeatBookingDto>? SeatBookings { get; set; }
        public FlightDto? Flight { get; set; }
    }

    //public class CreateReservationDto
    //{
    //    public int FlightId { get; set; }
    //    public List<CreateSeatBookingDto>? SeatBookings { get; set; }
    //    public decimal TotalAmount { get; set; }  
    //}

    public class SeatBookingDto
    {
        public int Id { get; set; }
        public string? SeatNumber { get; set; }
        public string? SeatClass { get; set; }
        public decimal Price { get; set; }
        public string? PassengerName { get; set; }
    }

    public class CreateSeatBookingDto
    {
        public string? SeatClass { get; set; } // "Business" or "Economy"
        public string? PassengerName { get; set; }
    }
    public class CreateReservationDto
    {
        public int FlightId { get; set; }
        public string SeatClass { get; set; } // "Business" or "Economy"
        public List<CreatePassengerDto> Passengers { get; set; }
    }

    public class CreatePassengerDto
    {
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
    }
}
