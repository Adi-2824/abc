﻿namespace WebApplication1.Models.Payment_Model_
{
    public class PaymentDto
    {
        public int Id { get; set; }
        public int ReservationId { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; }
        public string? TransactionId { get; set; }
        public string? Status { get; set; }
        public string? PaymentMethod { get; set; }
    }

    public class CreatePaymentDto
    {
        public int ReservationId { get; set; }
        public string? PaymentMethod { get; set; }


        public string SeatClass { get; set; } // "Business" or "Economy"
    }
}

    public class PaymentDtos
    {
    }

