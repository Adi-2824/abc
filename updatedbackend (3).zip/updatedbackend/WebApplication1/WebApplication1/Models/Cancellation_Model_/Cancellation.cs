﻿using WebApplication1.Models.Reservation_Model_;

namespace WebApplication1.Models.Cancellation_Model_
{
    public class Cancellation
    {
        public int Id { get; set; }
        public int ReservationId { get; set; }
        public DateTime CancellationDate { get; set; }
        public decimal RefundAmount { get; set; }
        public string? Reason { get; set; }

        public virtual Reservation? Reservation { get; set; }
    }
}
