﻿namespace WebApplication1.Models.Cancellation_Model_
{
    public class CancellationDto
    {
        public int Id { get; set; }
        public int ReservationId { get; set; }
        public DateTime CancellationDate { get; set; }
        public decimal RefundAmount { get; set; }
        public string? Reason { get; set; }
    }

    public class CreateCancellationDto
    {
        public int ReservationId { get; set; }
        public string?   Reason { get; set; }
    }

    public class CancellationDtos
    {
    }
}
