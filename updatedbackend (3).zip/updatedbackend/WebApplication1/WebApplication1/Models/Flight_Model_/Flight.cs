﻿using WebApplication1.Models.Reservation_Model_;

namespace WebApplication1.Models.Flight_Model_
{
    public class Flight
    {
        public int Id { get; set; }
        public string? FlightNumber { get; set; }
        public string? AirlineName { get; set; }
        public string? DepartureCity { get; set; }
        public string? ArrivalCity { get; set; }
        public DateTime DepartureTime { get; set; }
        public DateTime ArrivalTime { get; set; }
        public int TotalBusinessSeats { get; set; }
        public int TotalEconomySeats { get; set; }
        public int AvailableBusinessSeats { get; set; }
        public int AvailableEconomySeats { get; set; }
        public decimal BusinessClassPrice { get; set; }
        public decimal EconomyClassPrice { get; set; }
        public bool IsActive { get; set; } = true;

        public virtual ICollection<Reservation>? Reservations  { get; set; }
    }
}
