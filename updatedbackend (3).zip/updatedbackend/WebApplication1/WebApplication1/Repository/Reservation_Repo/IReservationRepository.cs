﻿using WebApplication1.Models.Reservation_Model_;

namespace WebApplication1.Repository.Reservation_Repo
{
    public interface IReservationRepository
    {
        Task<IEnumerable<Reservation>> GetReservations(int userId, bool isAdmin);
        Task<Reservation> GetReservationById(int id, int userId, bool isAdmin);
        Task<Reservation> CreateReservation(Reservation reservation);
    }
}
