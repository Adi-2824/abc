﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.DataAccessLayer;
using WebApplication1.Models.Reservation_Model_;

namespace WebApplication1.Repository.Reservation_Repo
{
    public class ReservationRepository : IReservationRepository
    {
        private readonly AppDbContext _context;

        public ReservationRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Reservation>> GetReservations(int userId, bool isAdmin)
        {
            var query = _context.Reservations
                .Include(r => r.Flight)
                .Include(r => r.SeatBookings)
                .AsQueryable();

            if (!isAdmin)
            {
                query = query.Where(r => r.UserId == userId);
            }

            return await query.ToListAsync();
        }

        public async Task<Reservation> GetReservationById(int id, int userId, bool isAdmin)
        {
            var reservation = await _context.Reservations
                .Include(r => r.Flight)
                .Include(r => r.SeatBookings)
                .FirstOrDefaultAsync(r => r.Id == id);

            if (reservation == null || (!isAdmin && reservation.UserId != userId))
            {
                return null;
            }

            return reservation;
        }

        public async Task<Reservation> CreateReservation(Reservation reservation)
        {
            _context.Reservations.Add(reservation);
            await _context.SaveChangesAsync();
            return reservation;
        }
    }
}