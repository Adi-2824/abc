﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using WebApplication1.Models.Cancellation_Model_;
using WebApplication1.Models.Flight_Model_;
using WebApplication1.Models.Payment_Model_;
using WebApplication1.Models.Reservation_Model_;
using WebApplication1.Models.SeatBooking_Model_;
using WebApplication1.Models.User_Model_;

namespace WebApplication1.DataAccessLayer
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Flight> Flights { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Reservation> Reservations { get; set; }
        public DbSet<SeatBooking> SeatBookings { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Cancellation> Cancellations { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure relationships
            modelBuilder.Entity<Reservation>()
                .HasOne(r => r.Flight)
                .WithMany(f => f.Reservations)
                .HasForeignKey(r => r.FlightId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Reservation>()
                .HasOne(r => r.User)
                .WithMany(u => u.Reservations)
                .HasForeignKey(r => r.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<SeatBooking>()
                .HasOne(sb => sb.Reservation)
                .WithMany(r => r.SeatBookings)
                .HasForeignKey(sb => sb.ReservationId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Payment>()
                .HasOne(p => p.Reservation)
                .WithOne(r => r.Payment)
                .HasForeignKey<Payment>(p => p.ReservationId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Cancellation>()
                .HasOne(c => c.Reservation)
                .WithOne(r => r.Cancellation)
                .HasForeignKey<Cancellation>(c => c.ReservationId)
                .OnDelete(DeleteBehavior.Cascade);

            // Configure decimal precision
            modelBuilder.Entity<Cancellation>().Property(c => c.RefundAmount).HasPrecision(18, 2);
            modelBuilder.Entity<Flight>().Property(f => f.BusinessClassPrice).HasPrecision(18, 2);
            modelBuilder.Entity<Flight>().Property(f => f.EconomyClassPrice).HasPrecision(18, 2);
            modelBuilder.Entity<Payment>().Property(p => p.Amount).HasPrecision(18, 2);
            modelBuilder.Entity<Reservation>().Property(r => r.TotalAmount).HasPrecision(18, 2);
            modelBuilder.Entity<SeatBooking>().Property(s => s.Price).HasPrecision(18, 2);

            // Seed User data with hashed passwords
            var passwordHasher = new PasswordHasher<User>();

            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    Username = "adminUser",
                    Email = "admin@gmail.com",
                    PasswordHash = passwordHasher.HashPassword(null, "Admin@123"),
                    FirstName = "Admin",
                    LastName = "User",
                    PhoneNumber = "1234567890",
                    Role = "Admin"
                },
                new User
                {
                    Id = 2,
                    Username = "Aman",
                    Email = "aman@example.com",
                    PasswordHash = passwordHasher.HashPassword(null, "User@123"),
                    FirstName = "Aman",
                    LastName = "Kumar",
                    PhoneNumber = "9876543210",
                    Role = "User"
                },
                new User
                {
                    Id = 3,
                    Username = "Sita",
                    Email = "sita@example.com",
                    PasswordHash = passwordHasher.HashPassword(null, "User@123"),
                    FirstName = "Sita",
                    LastName = "Ram",
                    PhoneNumber = "6549871230",
                    Role = "User"
                }
            );

            // Seed Flight data
            modelBuilder.Entity<Flight>().HasData(
                new Flight
                {
                    Id = 1,
                    FlightNumber = "AI101",
                    AirlineName = "Air India",
                    DepartureCity = "Delhi",
                    ArrivalCity = "Mumbai",
                    DepartureTime = new DateTime(2025, 05, 21, 07, 12, 53),
                    ArrivalTime = new DateTime(2025, 05, 21, 09, 30, 00),
                    TotalBusinessSeats = 30,
                    TotalEconomySeats = 150,
                    AvailableBusinessSeats=30,
                    AvailableEconomySeats=150,
                    BusinessClassPrice = 12000,
                    EconomyClassPrice = 5000
                },
                new Flight
                {
                    Id = 2,
                    FlightNumber = "6E302",
                    AirlineName = "IndiGo",
                    DepartureCity = "Bangalore",
                    ArrivalCity = "Chennai",
                    DepartureTime = new DateTime(2025, 06, 15, 08, 45, 00),
                    ArrivalTime = new DateTime(2025, 06, 15, 10, 00, 00),
                    TotalBusinessSeats = 20,
                    TotalEconomySeats = 180,
                    AvailableBusinessSeats = 20,
                    AvailableEconomySeats = 180,
                    BusinessClassPrice = 10000,
                    EconomyClassPrice = 4500
                },
                 new Flight
                 {
                     Id = 3,
                     FlightNumber = "SG555",
                     AirlineName = "SpiceJet",
                     DepartureCity = "Hyderabad",
                     ArrivalCity = "Goa",
                     DepartureTime = new DateTime(2025, 07, 10, 12, 30, 00),
                     ArrivalTime = new DateTime(2025, 07, 10, 14, 15, 00),
                     TotalBusinessSeats = 25,
                     TotalEconomySeats = 160,
                     AvailableBusinessSeats = 25,
                     AvailableEconomySeats = 160,
                     BusinessClassPrice = 11500,
                     EconomyClassPrice = 5200
                 },
                new Flight
                {
                    Id = 4,
                    FlightNumber = "EK501",
                    AirlineName = "Emirates",
                    DepartureCity = "Mumbai",
                    ArrivalCity = "Dubai",
                    DepartureTime = new DateTime(2025, 08, 05, 23, 15, 00),
                    ArrivalTime = new DateTime(2025, 08, 06, 02, 45, 00),
                    TotalBusinessSeats = 40,
                    TotalEconomySeats = 200,
                    AvailableBusinessSeats = 40,
                    AvailableEconomySeats = 200,
                    BusinessClassPrice = 30000,
                    EconomyClassPrice = 12000
                },
                new Flight
                {
                    Id = 5,
                    FlightNumber = "QR789",
                    AirlineName = "Qatar Airways",
                    DepartureCity = "Delhi",
                    ArrivalCity = "Doha",
                    DepartureTime = new DateTime(2025, 09, 20, 01, 00, 00),
                    ArrivalTime = new DateTime(2025, 09, 20, 04, 30, 00),
                    TotalBusinessSeats = 50,
                    TotalEconomySeats = 220,
                    AvailableBusinessSeats = 50,
                    AvailableEconomySeats = 220,
                    BusinessClassPrice = 35000,
                    EconomyClassPrice = 15000
                }

            );
        }
    }
}
