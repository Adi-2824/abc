﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models.Flight_Model_;
using WebApplication1.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication1.Repository.Flight_Repo;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class FlightsController : ControllerBase
    {
        private readonly IFlightRepository _flightRepository;

        public FlightsController(IFlightRepository flightRepository)
        {
            _flightRepository = flightRepository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<FlightDto>>> GetFlights(
            [FromQuery] string departureCity = null,
            [FromQuery] string arrivalCity = null,
            [FromQuery] DateTime? departureDate = null)
        {
            var flights = await _flightRepository.GetFlights(departureCity, arrivalCity, departureDate);
            return Ok(flights);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<FlightDto>> GetFlight(int id)
        {
            var flight = await _flightRepository.GetFlightById(id);
            if (flight == null)
                return NotFound();

            return new FlightDto
            {
                Id = flight.Id,
                FlightNumber = flight.FlightNumber,
                AirlineName = flight.AirlineName,
                DepartureCity = flight.DepartureCity,
                ArrivalCity = flight.ArrivalCity,
                DepartureTime = flight.DepartureTime,
                ArrivalTime = flight.ArrivalTime,
                AvailableBusinessSeats = flight.AvailableBusinessSeats,
                AvailableEconomySeats = flight.AvailableEconomySeats,
                BusinessClassPrice = flight.BusinessClassPrice,
                EconomyClassPrice = flight.EconomyClassPrice
            };
        }

        [HttpPost]
        //[Authorize(Roles = "Admin")]
        public async Task<ActionResult<FlightDto>> CreateFlight(CreateFlightDto createFlightDto)
        {
            var flight = new Flight
            {
                FlightNumber = createFlightDto.FlightNumber,
                AirlineName = createFlightDto.AirlineName,
                DepartureCity = createFlightDto.DepartureCity,
                ArrivalCity = createFlightDto.ArrivalCity,
                DepartureTime = createFlightDto.DepartureTime,
                ArrivalTime = createFlightDto.ArrivalTime,
                TotalBusinessSeats = createFlightDto.TotalBusinessSeats,
                TotalEconomySeats = createFlightDto.TotalEconomySeats,
                AvailableBusinessSeats = createFlightDto.TotalBusinessSeats,
                AvailableEconomySeats = createFlightDto.TotalEconomySeats,
                BusinessClassPrice = createFlightDto.BusinessClassPrice,
                EconomyClassPrice = createFlightDto.EconomyClassPrice,
                IsActive = true
            };

            var createdFlight = await _flightRepository.CreateFlight(flight);
            return CreatedAtAction(nameof(GetFlight), new { id = createdFlight.Id }, createdFlight);
        }

        [HttpPut("{id}")]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateFlight(int id, UpdateFlightDto updateFlightDto)
        {
            var flight = new Flight
            {
                FlightNumber = updateFlightDto.FlightNumber,
                AirlineName = updateFlightDto.AirlineName,
                DepartureCity = updateFlightDto.DepartureCity,
                ArrivalCity = updateFlightDto.ArrivalCity,
                DepartureTime = updateFlightDto.DepartureTime,
                ArrivalTime = updateFlightDto.ArrivalTime,
                BusinessClassPrice = updateFlightDto.BusinessClassPrice,
                EconomyClassPrice = updateFlightDto.EconomyClassPrice
            };

            var updated = await _flightRepository.UpdateFlight(id, flight);
            return updated ? NoContent() : NotFound();
        }

        [HttpDelete("{id}")]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteFlight(int id)
        {
            var deleted = await _flightRepository.DeleteFlight(id);
            return deleted ? NoContent() : NotFound();
        }
    }
}