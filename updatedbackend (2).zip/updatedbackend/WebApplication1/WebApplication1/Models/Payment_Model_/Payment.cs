﻿using WebApplication1.Models.Reservation_Model_;

namespace WebApplication1.Models.Payment_Model_
{
    public enum PaymentStatus
    {
        Pending,
        Completed,
        Failed,
        Refunded
    }

    public class Payment
    {
        public int Id { get; set; }
        public int ReservationId { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; }
        public string? TransactionId { get; set; }
        public PaymentStatus Status { get; set; }
        public string? PaymentMethod { get; set; }

        public virtual Reservation? Reservation { get; set; }

    }
}
