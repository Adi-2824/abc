﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models.Payment_Model_;
using WebApplication1.Repository.Payment_Repo;
using WebApplication1.Repository.Reservation_Repo;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using WebApplication1.Models.Reservation_Model_;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PaymentsController : ControllerBase
    {
        private readonly IPaymentRepository _paymentRepository;
        private readonly IReservationRepository _reservationRepository;
        private readonly ILogger<PaymentsController> _logger;

        public PaymentsController(IPaymentRepository paymentRepository, IReservationRepository reservationRepository, ILogger<PaymentsController> logger)
        {
            _paymentRepository = paymentRepository;
            _reservationRepository = reservationRepository;
            _logger = logger;
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<IEnumerable<PaymentDto>>> GetPayments()
        {
            var payments = await _paymentRepository.GetPayments();

            return Ok(payments.Select(p => new PaymentDto
            {
                Id = p.Id,
                ReservationId = p.ReservationId,
                Amount = p.Amount,
                PaymentDate = p.PaymentDate,
                TransactionId = p.TransactionId,
                Status = p.Status.ToString(),
                PaymentMethod = p.PaymentMethod
            }));
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<PaymentDto>> GetPayment(int id)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdClaim, out int userId))
            {
                _logger.LogError("User ID is null or invalid.");
                return Unauthorized(new { message = "User authentication failed." });
            }

            bool isAdmin = User.IsInRole("Admin");
            var payment = await _paymentRepository.GetPaymentById(id);

            if (payment == null)
            {
                return NotFound();
            }

            if (!isAdmin && payment.Reservation.UserId != userId)
            {
                return Forbid();
            }

            return Ok(new PaymentDto
            {
                Id = payment.Id,
                ReservationId = payment.ReservationId,
                Amount = payment.Amount,
                PaymentDate = payment.PaymentDate,
                TransactionId = payment.TransactionId,
                Status = payment.Status.ToString(),
                PaymentMethod = payment.PaymentMethod
            });
        }

        [HttpPost]
        public async Task<ActionResult<PaymentDto>> CreatePayment(CreatePaymentDto createPaymentDto)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdClaim, out int userId))
            {
                _logger.LogError("User ID is null or invalid.");
                return Unauthorized(new { message = "User authentication failed." });
            }

            bool isAdmin = User.IsInRole("Admin");

            // **FIXED: Get Reservation using `_reservationRepository`**
            var reservation = await _reservationRepository.GetReservationById(createPaymentDto.ReservationId, userId, isAdmin);
            if (reservation == null)
            {
                return BadRequest(new { message = "Reservation not found" });
            }

            if (!isAdmin && reservation.UserId != userId)
            {
                return Forbid();
            }

            if (reservation.Payment != null)
            {
                return BadRequest(new { message = "Payment already exists for this reservation" });
            }

            if (reservation.Status != ReservationStatus.Pending)
            {
                return BadRequest(new { message = $"Cannot process payment for reservation in {reservation.Status} state" });
            }

            string transactionId = Guid.NewGuid().ToString("N");

            var payment = new Payment
            {
                ReservationId = reservation.Id,
                Amount = reservation.TotalAmount,
                PaymentDate = DateTime.UtcNow,
                TransactionId = transactionId,
                Status = PaymentStatus.Completed,
                PaymentMethod = createPaymentDto.PaymentMethod
            };

            var createdPayment = await _paymentRepository.CreatePayment(payment);

            return CreatedAtAction(nameof(GetPayment), new { id = createdPayment.Id }, new PaymentDto
            {
                Id = createdPayment.Id,
                ReservationId = createdPayment.ReservationId,
                Amount = createdPayment.Amount,
                PaymentDate = createdPayment.PaymentDate,
                TransactionId = createdPayment.TransactionId,
                Status = createdPayment.Status.ToString(),
                PaymentMethod = createdPayment.PaymentMethod
            });
        }
    }
}
