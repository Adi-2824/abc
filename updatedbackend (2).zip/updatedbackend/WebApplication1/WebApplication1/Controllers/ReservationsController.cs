﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models.Reservation_Model_;
using WebApplication1.Repository.Reservation_Repo;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using WebApplication1.Models.Flight_Model_;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ReservationsController : ControllerBase
    {
        private readonly IReservationRepository _reservationRepository;
        private readonly ILogger<ReservationsController> _logger;

        public ReservationsController(IReservationRepository reservationRepository, ILogger<ReservationsController> logger)
        {
            _reservationRepository = reservationRepository;
            _logger = logger;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ReservationDto>>> GetReservations()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdClaim, out int userId))
            {
                _logger.LogError("User ID is null or invalid.");
                return Unauthorized(new { message = "User authentication failed." });
            }

            bool isAdmin = User.IsInRole("Admin");
            var reservations = await _reservationRepository.GetReservations(userId, isAdmin);

            return Ok(reservations.Select(r => new ReservationDto
            {
                Id = r.Id,
                FlightId = r.FlightId,
                ReservationDate = r.ReservationDate,
                Status = r.Status.ToString(),
                TotalAmount = r.TotalAmount,
                SeatBookings = r.SeatBookings.Select(sb => new SeatBookingDto
                {
                    Id = sb.Id,
                    SeatNumber = sb.SeatNumber,
                    SeatClass = sb.SeatClass.ToString(),
                    Price = sb.Price,
                    PassengerName = sb.PassengerName
                }).ToList(),
                Flight = new FlightDto
                {
                    Id = r.Flight.Id,
                    FlightNumber = r.Flight.FlightNumber,
                    AirlineName = r.Flight.AirlineName,
                    DepartureCity = r.Flight.DepartureCity,
                    ArrivalCity = r.Flight.ArrivalCity,
                    DepartureTime = r.Flight.DepartureTime,
                    ArrivalTime = r.Flight.ArrivalTime,
                    AvailableBusinessSeats = r.Flight.AvailableBusinessSeats,
                    AvailableEconomySeats = r.Flight.AvailableEconomySeats,
                    BusinessClassPrice = r.Flight.BusinessClassPrice,
                    EconomyClassPrice = r.Flight.EconomyClassPrice
                }
            }));
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ReservationDto>> GetReservation(int id)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdClaim, out int userId))
            {
                _logger.LogError("User ID is null or invalid.");
                return Unauthorized(new { message = "User authentication failed." });
            }

            bool isAdmin = User.IsInRole("Admin");
            var reservation = await _reservationRepository.GetReservationById(id, userId, isAdmin);

            if (reservation == null)
            {
                return NotFound(new { message = "Reservation not found or unauthorized access." });
            }

            return Ok(new ReservationDto
            {
                Id = reservation.Id,
                FlightId = reservation.FlightId,
                ReservationDate = reservation.ReservationDate,
                Status = reservation.Status.ToString(),
                TotalAmount = reservation.TotalAmount,
                SeatBookings = reservation.SeatBookings.Select(sb => new SeatBookingDto
                {
                    Id = sb.Id,
                    SeatNumber = sb.SeatNumber,
                    SeatClass = sb.SeatClass.ToString(),
                    Price = sb.Price,
                    PassengerName = sb.PassengerName
                }).ToList(),
                Flight = new FlightDto
                {
                    Id = reservation.Flight.Id,
                    FlightNumber = reservation.Flight.FlightNumber,
                    AirlineName = reservation.Flight.AirlineName,
                    DepartureCity = reservation.Flight.DepartureCity,
                    ArrivalCity = reservation.Flight.ArrivalCity,
                    DepartureTime = reservation.Flight.DepartureTime,
                    ArrivalTime = reservation.Flight.ArrivalTime,
                    AvailableBusinessSeats = reservation.Flight.AvailableBusinessSeats,
                    AvailableEconomySeats = reservation.Flight.AvailableEconomySeats,
                    BusinessClassPrice = reservation.Flight.BusinessClassPrice,
                    EconomyClassPrice = reservation.Flight.EconomyClassPrice
                }
            });
        }

        [HttpPost]
        public async Task<ActionResult<ReservationDto>> CreateReservation(CreateReservationDto createReservationDto)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdClaim, out int userId))
            {
                _logger.LogError("User ID is null or invalid.");
                return Unauthorized(new { message = "User authentication failed." });
            }

            var reservation = new Reservation
            {
                FlightId = createReservationDto.FlightId,
                UserId = userId,
                ReservationDate = DateTime.UtcNow,
                Status = ReservationStatus.Pending,
                TotalAmount = createReservationDto.TotalAmount
            };

            var createdReservation = await _reservationRepository.CreateReservation(reservation);
            return CreatedAtAction(nameof(GetReservation), new { id = createdReservation.Id }, createdReservation);
        }
    }
}