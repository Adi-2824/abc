﻿using WebApplication1.Models.User_Model_;

namespace WebApplication1.Repository.User_Repo
{
    public interface IAuthService
    {

           

    
            string GenerateJwtToken(User user);
            string HashPassword(string password);
            bool VerifyPassword(string password, string passwordHash);
            Task<UserDto> RegisterUser(RegisterUserDto registerDto);
            Task<UserDto?> AuthenticateUser(LoginDto loginDto);
        
    }


}

