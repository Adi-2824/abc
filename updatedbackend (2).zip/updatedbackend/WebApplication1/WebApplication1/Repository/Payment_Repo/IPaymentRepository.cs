﻿using WebApplication1.Models.Payment_Model_;

namespace WebApplication1.Repository.Payment_Repo
{
    public interface IPaymentRepository
    {
        Task<IEnumerable<Payment>> GetPayments();
        Task<Payment> GetPaymentById(int id);
        Task<Payment> CreatePayment(Payment payment);

    }
}
