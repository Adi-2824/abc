﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.DataAccessLayer;
using WebApplication1.Models.Payment_Model_;
using WebApplication1.Models.Reservation_Model_;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Repository.Payment_Repo
{
    public class PaymentRepository : IPaymentRepository
    {
        private readonly AppDbContext _context;

        public PaymentRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Payment>> GetPayments()
        {
            return await _context.Payments
                .Include(p => p.Reservation)
                .ToListAsync();
        }

        public async Task<Payment> GetPaymentById(int id)
        {
            return await _context.Payments
                .Include(p => p.Reservation)
                .FirstOrDefaultAsync(p => p.Id == id);
        }

        public async Task<Payment> CreatePayment(Payment payment)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                _context.Payments.Add(payment);

                // Update reservation status to Confirmed
                var reservation = await _context.Reservations.FindAsync(payment.ReservationId);
                if (reservation != null)
                {
                    reservation.Status = ReservationStatus.Confirmed;
                }

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                return payment;
            }
            catch
            {
                await transaction.RollbackAsync();
                throw;
            }
        }
    }
}