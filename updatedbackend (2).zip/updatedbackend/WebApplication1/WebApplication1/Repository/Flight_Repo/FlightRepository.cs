﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.DataAccessLayer;
using WebApplication1.Models.Flight_Model_;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Repository.Flight_Repo;

namespace WebApplication1.Repositories
{
    public class FlightRepository : IFlightRepository
    {
        private readonly AppDbContext _context;

        public FlightRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Flight>> GetFlights(string departureCity, string arrivalCity, DateTime? departureDate)
        {
            var query = _context.Flights.Where(f => f.IsActive).AsQueryable();

            if (!string.IsNullOrEmpty(departureCity))
                query = query.Where(f => f.DepartureCity.ToLower().Contains(departureCity.ToLower()));

            if (!string.IsNullOrEmpty(arrivalCity))
                query = query.Where(f => f.ArrivalCity.ToLower().Contains(arrivalCity.ToLower()));

            if (departureDate.HasValue)
                query = query.Where(f => f.DepartureTime.Date == departureDate.Value.Date);

            return await query.ToListAsync();
        }

        public async Task<Flight> GetFlightById(int id)
        {
            return await _context.Flights.FirstOrDefaultAsync(f => f.Id == id && f.IsActive);
        }

        public async Task<Flight> CreateFlight(Flight flight)
        {
            _context.Flights.Add(flight);
            await _context.SaveChangesAsync();
            return flight;
        }

        public async Task<bool> UpdateFlight(int id, Flight flight)
        {
            var existingFlight = await _context.Flights.FindAsync(id);
            if (existingFlight == null || !existingFlight.IsActive)
                return false;

            existingFlight.FlightNumber = flight.FlightNumber;
            existingFlight.AirlineName = flight.AirlineName;
            existingFlight.DepartureCity = flight.DepartureCity;
            existingFlight.ArrivalCity = flight.ArrivalCity;
            existingFlight.DepartureTime = flight.DepartureTime;
            existingFlight.ArrivalTime = flight.ArrivalTime;
            existingFlight.BusinessClassPrice = flight.BusinessClassPrice;
            existingFlight.EconomyClassPrice = flight.EconomyClassPrice;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteFlight(int id)
        {
            var flight = await _context.Flights.FindAsync(id);
            if (flight == null)
                return false;

            flight.IsActive = false; // Soft delete
            await _context.SaveChangesAsync();
            return true;
        }

        public bool FlightExists(int id)
        {
            return _context.Flights.Any(e => e.Id == id);
        }
    }
}