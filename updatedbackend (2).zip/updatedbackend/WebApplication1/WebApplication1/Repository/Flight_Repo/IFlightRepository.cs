﻿using WebApplication1.Models.Flight_Model_;

namespace WebApplication1.Repository.Flight_Repo
{
    public interface IFlightRepository
    {
        Task<IEnumerable<Flight>> GetFlights(string departureCity, string arrivalCity, DateTime? departureDate);
        Task<Flight> GetFlightById(int id);
        Task<Flight> CreateFlight(Flight flight);
        Task<bool> UpdateFlight(int id, Flight flight);
        Task<bool> DeleteFlight(int id);
        bool FlightExists(int id);

    }
}
