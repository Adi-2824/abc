﻿namespace WebApplication1.AuthConfiguration
{
    public class JwtSettings
    {
        public string Secret { get; set; } = "KHPK6Ucf/zjvU4qW8/vkuuGLHeIo0l9ACJiTaAPLKbk=";
        public string? Issuer { get; set; }
        public string? Audience { get; set; }
        //public int ExpirationInMinutes { get; set; }

    }
}
